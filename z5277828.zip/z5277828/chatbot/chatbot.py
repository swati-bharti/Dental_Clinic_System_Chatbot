from flask import Flask, render_template, request
from rivescript import RiveScript
import requests
import os
import re
import requests

# global lists to store available and reserved timeslots of each doctor
available_timeslot_swati = []
available_timeslot_puja = []
available_timeslot_madhushi = []
reserved_timeslot_swati = []
reserved_timeslot_puja = []
reserved_timeslot_madhushi = []

# Authorization header for wit.ai
TOKEN = "Bearer JQZH75LFSQTBEFFVK6WXCS2DEROEXWBV"

# function to get detials of the dentist
def get_dentist_details(dentist_name):
     result = requests.get('http://127.0.0.1:8080/v1/dentist/findByName?expression={}'.format(dentist_name))
     details_json = result.json()
     location = details_json[0]["location"][0]
     name = details_json[0]["name"][0]
     specialisation = details_json[0]["specialisation"][0]
     return_statement  = '{} is based in {} and is specialised in {}'.format(name,location,specialisation)
     return return_statement
    
# function to get the list of dentists
def get_dentist_list():
     result = requests.get('http://127.0.0.1:8080/v1/dentist')
     name_list_json = result.json()
     name = []
     for i in range(0,len(name_list_json[0]["name"])):
         name.append(name_list_json[0]["name"][i])
     return_statement =  'the available doctors are:{}'.format(name)
     return return_statement

# function to assign available_timeslot and reserved_timeslot
def assign_available_and_reserved_timeslots(dentist_name):
     if(dentist_name == "swati"):
          available_timeslot = available_timeslot_swati
          reserved_timeslot = reserved_timeslot_swati
          
          return available_timeslot, reserved_timeslot
     
     if(dentist_name == "puja"):
          available_timeslot = available_timeslot_puja
          reserved_timeslot = reserved_timeslot_puja
          
          return available_timeslot, reserved_timeslot
     
     if(dentist_name == "madhushi"):
          available_timeslot = available_timeslot_madhushi
          reserved_timeslot = reserved_timeslot_madhushi
          
          return available_timeslot, reserved_timeslot
     
# function to get the timings of a particular doctor
def get_dentist_timings(dentist_name):
     result = requests.get('http://127.0.0.1:8082/v1/timeSlot?expression={}'.format(dentist_name))
     timings_json = result.json()
     date = timings_json[0]['date']
     dentist_name = timings_json[0]['doctor_name']

     available_timeslot, reserved_timeslot = assign_available_and_reserved_timeslots(dentist_name)
     
     # to get the available and reserved timeslots
     if len(available_timeslot) != 0:
          available_timeslot = available_timeslot
     else:
          for i in range(0,len(timings_json[0]["available_timeslot"])):
               available_timeslot.append(timings_json[0]["available_timeslot"][i])

     if len(reserved_timeslot) != 0:
          reserved_timeslot = reserved_timeslot
     else:
          for i in range(0,len(timings_json[0]["reserved_timeslot"])):
               reserved_timeslot.append(timings_json[0]["reserved_timeslot"][i])
     return_statement = "{} is available at:{} these times on {} and is reserved at {} these times".format(dentist_name, available_timeslot, date, reserved_timeslot)

     #reverse logic of assign available_timeslot and reserved_timeslot
     if(dentist_name == "swati"):
           available_timeslot_swati = available_timeslot
           reserved_timeslot_swati = reserved_timeslot
           
     if(dentist_name == "puja"):
          available_timeslot_puja = available_timeslot
          reserved_timeslot_puja = reserved_timeslot
          
     if(dentist_name == "madhushi"):
          available_timeslot_madhushi = available_timeslot
          reserved_timeslot_madhushi = reserved_timeslot
          
     return return_statement

# function to get the timings only
def get_dentist_timings_only_time(dentist_name):
     result = requests.get('http://127.0.0.1:8082/v1/timeSlot?expression={}'.format(dentist_name))
     timings_json = result.json()
     date = timings_json[0]['date']
     dentist_name = timings_json[0]['doctor_name']
     available_timeslot, reserved_timeslot = assign_available_and_reserved_timeslots(dentist_name)
     
     # to get the available and reserved timeslots
     if len(available_timeslot) != 0:
          available_timeslot = available_timeslot
     else:
          for i in range(0,len(timings_json[0]["available_timeslot"])):
               available_timeslot.append(timings_json[0]["available_timeslot"][i])

     if len(reserved_timeslot) != 0:
          reserved_timeslot = reserved_timeslot
     else:
          for i in range(0,len(timings_json[0]["reserved_timeslot"])):
               reserved_timeslot.append(timings_json[0]["reserved_timeslot"][i])
               
     # reverse logic of assign available_timeslot and reserved_timeslot
     if(dentist_name == "swati"):
           available_timeslot_swati = available_timeslot 
           reserved_timeslot_swati = reserved_timeslot
           
           return available_timeslot_swati, reserved_timeslot_swati, date
          
     if(dentist_name == "puja"):
          available_timeslot_puja = available_timeslot
          reserved_timeslot_puja = reserved_timeslot
          
          return available_timeslot_puja, reserved_timeslot_puja, date
     
     if(dentist_name == "madhushi"):
          available_timeslot_madhushi = available_timeslot
          reserved_timeslot_madhushi = reserved_timeslot
          
          return available_timeslot_madhushi, reserved_timeslot_madhushi, date
     
# function to book an appointment with a particular doctor
def book_dentist(dentist_name,booking_time):
     available_timeslot,reserved_timeslot,date = get_dentist_timings_only_time(dentist_name)
     
     # flag
     status = 0
     
     # formatting the booking time 
     booking_time = booking_time.split("-")
     if ('A' in booking_time[0]):
          booking_time = booking_time[0].replace('A''M',"")
     else:
          booking_time = booking_time[0].replace('P''M',"") 
     for i in range(0,len(available_timeslot)):
           copy_available_timeslot =  available_timeslot[i]
           available_timeslot_new =  available_timeslot[i].split("-")
           if ('A' in available_timeslot_new[0]):
                available_timeslot_new = available_timeslot_new[0].replace('A''M',"")
           else:
                available_timeslot_new = available_timeslot_new[0].replace('P''M',"")
                
           #to check the similarity between booking_time and available_time
           if(int(booking_time)-int(available_timeslot_new) == 0):
                copy_available_timeslot = copy_available_timeslot
                status = 1
                break
                
     if(status == 1):
          reserved_timeslot = reserved_timeslot.append(copy_available_timeslot)
          available_timeslot = available_timeslot.remove(copy_available_timeslot)
          return_statement = "Your booking with doctor {} at {} on {} is Successful!!".format(dentist_name,copy_available_timeslot,date)

     else:
         return_statement = "Sorry :( this time slot is reserved. The available time slots for {} are{}".format(date, available_timeslot)
         
     # reverse logic of assign available_timeslot and reserved_timeslot
     if(dentist_name == "swati"):
           available_timeslot_swati = available_timeslot
           reserved_timeslot_swati = reserved_timeslot
           
     if(dentist_name == "puja"):
          available_timeslot_puja = available_timeslot
          reserved_timeslot_puja = reserved_timeslot
          
     if(dentist_name == "madhushi"):
          available_timeslot_madhushi = available_timeslot
          reserved_timeslot_madhushi = reserved_timeslot
          
     return return_statement
          
# funtion to cancel a booking of a particular doctor
def cancel_dentist(dentist_name,booking_time):
     available_timeslot,reserved_timeslot,date = get_dentist_timings_only_time(dentist_name)

     #flag
     status = 0
     
     # formatting the booking time 
     booking_time = booking_time.split("-")
     if ('A' in booking_time[0]):
          booking_time = booking_time[0].replace('A''M',"")
     else:
          booking_time = booking_time[0].replace('P''M',"")
          
     # formatting the available_timeslot  
     for i in range(0,len(reserved_timeslot)):
           copy_reserved_timeslot =  reserved_timeslot[i]
           reserved_timeslot_new =  reserved_timeslot[i].split("-")
           if ('A' in reserved_timeslot_new[0]):
                reserved_timeslot_new = reserved_timeslot_new[0].replace('A''M',"")
           else:
                reserved_timeslot_new = reserved_timeslot_new[0].replace('P''M',"")
                
           #to check the similarity between booking_time and available_time
           if(int(booking_time)-int(reserved_timeslot_new) == 0):
                copy_reserved_timeslot = copy_reserved_timeslot
                status =1
                break
                
     if(status == 1):
          reserved_timeslot = reserved_timeslot.remove(copy_reserved_timeslot)
          available_timeslot = available_timeslot.append(copy_reserved_timeslot)
          return_statement = "Your booking with doctor {} at {} on {} is Cancelled!!".format(dentist_name,copy_reserved_timeslot,date)
     else:
          return_statement = "Sorry :( this time slot is not booked and is available for booking."
          
     #reverse logic of assign available_timeslot and reserved_timeslot
     if(dentist_name == "swati"):
           available_timeslot_swati = available_timeslot
           reserved_timeslot_swati = reserved_timeslot
           
     if(dentist_name == "puja"):
          available_timeslot_puja = available_timeslot
          reserved_timeslot_puja = reserved_timeslot
          
     if(dentist_name == "madhushi"):
          available_timeslot_madhushi = available_timeslot
          reserved_timeslot_madhushi = reserved_timeslot
          
     return return_statement
# function to ge the confirmation message
def get_confirmation():
     return_statement = 'do you really want to cancel the booking?(yes/no)'
     return return_statement

# function to call wit.ai api
def ask_wit(expression):
    result = requests.get('https://api.wit.ai/message?v=20201118&q={}'.format(expression),
                          headers={'Authorization': TOKEN})
    jsonResult = result.json()
    try:
        
        # to get the detials of a particular dentist
        if jsonResult['intents'][0]['name'] == 'GetDentistDetails':
            dentist_name = jsonResult['entities']["wit$contact:contact"][0]['value']
            dentist_name = dentist_name.lower()
            dentist_name =dentist_name.replace('d''r',"")
            dentist_name = dentist_name.strip()
            answer = get_dentist_details(dentist_name)
            return answer
            
        # to get the list of dentists
        if jsonResult['intents'][0]['name'] == 'GetDentistList':
            answer = get_dentist_list()
            return answer
          
        # to get timings of a particular dentist
        if jsonResult['intents'][0]['name'] == 'GetDentistTimings':
             dentist_name = jsonResult['entities']["wit$contact:contact"][0]['value']
             dentist_name = dentist_name.lower()
             dentist_name =dentist_name.replace('d''r',"")
             dentist_name = dentist_name.strip()
             answer = get_dentist_timings(dentist_name)
             return answer

        # to book an appointment with a particular dentist
        if jsonResult['intents'][0]['name'] == 'BookDentist':
             dentist_name = jsonResult['entities']["wit$contact:contact"][0]['value']
             dentist_name = dentist_name.lower()
             dentist_name =dentist_name.replace('d''r',"")
             dentist_name = dentist_name.strip()
             booking_time = jsonResult['entities']["wit$datetime:datetime"][0]['body']
             booking_time = booking_time.replace("at","")
             answer = book_dentist(dentist_name,booking_time)
             return answer

        # to cancel an appointment with a particular dentist
        if jsonResult['intents'][0]['name'] == 'CancelDentist':
             global dentist_name_temp
             dentist_name_temp = jsonResult['entities']["wit$contact:contact"][0]['value']
             dentist_name_temp = dentist_name_temp.lower()
             dentist_name_temp =dentist_name_temp.replace('d''r',"")
             dentist_name_temp = dentist_name_temp.strip()
             global booking_time_temp
             booking_time_temp = jsonResult['entities']["wit$datetime:datetime"][0]['body']
             booking_time_temp = booking_time_temp.replace("at","")
             answer = get_confirmation()
             return answer
          
        # to check the confirmation (yes/no)
        if jsonResult['intents'][0]['name'] == 'ConfirmationMsg':
             confirmation = jsonResult["entities"]["boolean_value:boolean_value"][0]["body"]
             confirmation = confirmation.lower()
             if(confirmation == "yes"):
                  answer = cancel_dentist(dentist_name_temp,booking_time_temp)
             else:
                  answer = "Your booking is not cancelled"
    
             return answer


    except (IndexError,KeyError) as err:
        answer = "I dont understand :("
        return answer
    

app = Flask(__name__)

# rivescript code
username = 'swati'
bot = RiveScript(utf8=True)
bot.unicode_punctuation = re.compile(r'[.,!?;:]')
bot.load_directory(os.path.join(os.path.dirname(__file__), ".", "brain"))
bot.sort_replies()

# function to get the template from templates folder
@app.route("//")
def home(): 
 return render_template("index.html")

# function to take response from user and return the answer from bot 
@app.route("/get")
def get_bot_response(): 
 expression = request.args.get('msg')
 answer = bot.reply(username, expression)  
 if "ERR" in answer:
      answer = ask_wit(expression)
 return answer

# main
if __name__ == "__main__": 
 app.run(debug=True)
