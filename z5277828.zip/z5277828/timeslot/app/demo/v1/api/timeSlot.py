# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

from flask import request, g

from . import Resource
from .. import schemas
from datetime import date
import json
import os

class Timeslot(Resource):

    def get(self):
        date_ = date.today()
        doctor_time_slots = json.load(open(os.path.join(os.path.dirname(__file__),"timeslot.json"),"r"))
        expression = g.args.get("expression")
        expression = expression.lower()
        available_timeslot = []
        reserved_timeslot = []
        name = expression
        for i in range(0,len(doctor_time_slots["time_slot_"+str(name)])):
            if(doctor_time_slots["time_slot_"+str(name)][i]["status"] == "Available"):
                available_timeslot.append(doctor_time_slots["time_slot_"+str(name)][i]["time"])
            else:
                reserved_timeslot.append(doctor_time_slots["time_slot_"+str(name)][i]["time"])

        print(g.args)

        return [{"date": date_,"doctor_name": name, "reserved_timeslot": reserved_timeslot,"available_timeslot": available_timeslot}], 200, None
