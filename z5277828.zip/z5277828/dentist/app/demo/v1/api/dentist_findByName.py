# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

from flask import request, g

from . import Resource
from .. import schemas
import json
import os

class DentistFindbyname(Resource):

    def get(self):
        detials_of_doctors = json.load(open(os.path.join(os.path.dirname(__file__),"dentist.json"),"r"))
        expression = g.args.get("expression")
        expression = expression.lower()
        Names = []
        Location = []
        Specialisation = []
        print(len(detials_of_doctors["Doctors"]))
        for i in range(0,len(detials_of_doctors["Doctors"])):
            if( expression in detials_of_doctors["Doctors"][i]["name"]):
                 Names.append(detials_of_doctors["Doctors"][i]["name"])
                 Location.append(detials_of_doctors["Doctors"][i]["location"])
                 Specialisation.append(detials_of_doctors["Doctors"][i]["specialisation"])
         
        print(g.args)

        return [{"name": Names,"location": Location,"specialisation": Specialisation }], 200, None
