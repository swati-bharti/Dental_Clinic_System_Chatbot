# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

from flask import request, g

from . import Resource
from .. import schemas
import json
import os

class Dentist(Resource):

    def get(self):
        names_of_doctors = json.load(open(os.path.join(os.path.dirname(__file__),"dentist.json"),"r"))
        Names = []
        print(len(names_of_doctors["Doctors"]))
        for i in range(0,len(names_of_doctors["Doctors"])):
            Names.append(names_of_doctors["Doctors"][i]["name"])

        return [{"name": Names}], 200, None
